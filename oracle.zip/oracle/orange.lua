
local burntOrange = Item.new("Shredded Orange Soul")

burntOrange.pickupText = "The shredded remains of something...almost organic. Worthless in any significant way."

burntOrange.sprite = Sprite.load("Orange.png", 1, 12, 13)

local teamItemCount = 0

burntOrange:setTier("rare")
burntOrange:setLog{
	group = "rare",
	description = "The shredded remains of something...almost organic. Worthless in any significant way.",
	story = "Purrs with energy similar to the Oracle's connective tissue.",
	destination = "Room 45, Building E,\nSedna abnormal biology research station,\n90377 Sedna",
	date = "14/4/2058"
}

registercallback("onGameStart", function()
	teamItemCount = 0
end)

burntOrange:addCallback("pickup", function(player)
	teamItemCount = teamItemCount + 1
end)

burntOrange:setTier("rare")

burntOrange:addCallback("pickup", function(player)
	player:set("maxhp", player:get("maxhp") * 1.2)
end)

