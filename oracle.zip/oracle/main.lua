
------ main.lua
---- This file is automatically loaded by RoRML

-- Loads the other Lua scripts


require("red")

require("orange")

require("yellow")

require("oracle")
