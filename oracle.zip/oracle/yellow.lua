
local burntYellow = Item.new("Shattered Yellow Soul")

burntYellow.pickupText = "The shattered remains of something...almost organic. Worthless in any considerable way."

burntYellow.sprite = Sprite.load("Yellow.png", 1, 12, 13)

local teamItemCount = 0
burntYellow:setTier("rare")
burntYellow:setLog{
	group = "rare",
	description = "The shattered remains of something...almost organic. Worthless in any considerable way.",
	story = "resonates with energy similar to the Oracle's shell.",
	destination = "Room 45, Building E,\nSedna abnormal biology research station,\n90377 Sedna",
	date = "14/4/2058"
}

registercallback("onGameStart", function()
	teamItemCount = 0
end)

burntYellow:addCallback("pickup", function(player)
	teamItemCount = teamItemCount + 1
end)

burntYellow:setTier("rare")

burntYellow:addCallback("pickup", function(player)
	player:set("attack_speed", player:get("attack_speed") * 1.15)
end)

