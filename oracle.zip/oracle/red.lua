
local burntRed = Item.new("Burnt Red Soul")

burntRed.pickupText = "The charred remains of something...almost organic. Worthless in any meaningful way."

burntRed.sprite = Sprite.load("Red.png", 1, 12, 13)

local teamItemCount = 0

burntRed:setTier("rare")
burntRed:setLog{
	group = "rare",
	description = "The charred remains of something...almost organic. Worthless in any meaningful way.",
	story = "Hums with energy similar to the Oracle's eye.",
	destination = "Room 45, Building E,\nSedna abnormal biology research station,\n90377 Sedna",
	date = "14/4/2058"
}


registercallback("onGameStart", function()
	teamItemCount = 0
end)

burntRed:addCallback("pickup", function(player)
	teamItemCount = teamItemCount + 1
end)

burntRed:setTier("rare")

burntRed:addCallback("pickup", function(player)
	player:set("damage", player:get("damage") * 1.1)
end)

