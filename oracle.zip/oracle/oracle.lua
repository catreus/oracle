
------oracle.lua
---catreus95


local oracle = Survivor.new("Oracle of the Sun")

local sprites = {
	idle = Sprite.load("oracle_idle", "oracle/idle", 18, 8, 19),
	walk = Sprite.load("oracle_walk", "oracle/walk", 15, 8, 16),
	jump = Sprite.load("oracle_jump", "oracle/jump", 18, 8, 15),
	climb = Sprite.load("oracle_climb", "oracle/climb", 2, 8, 15),
	death = Sprite.load("oracle_death", "oracle/death", 12, 5, 19),
	decoy = Sprite.load("oracle_decoy", "oracle/decoy", 1, 5, 15),

	idleA = Sprite.load("oracle_idleA", "oracle/idleA", 18, 8, 19),
	walkA = Sprite.load("oracle_walkA", "oracle/walkA", 15, 8, 16),
	jumpA = Sprite.load("oracle_jumpA", "oracle/jumpA", 18, 8, 15),
	climbA = Sprite.load("oracle_climbA", "oracle/climbA", 2, 8, 15),


}	--shoot sprites
local sprShoot1 = Sprite.load("oracle_shoot1", "oracle/shoot1", 16, 8, 23)
local sprShoot1A = Sprite.load("oracle_shoot1A", "oracle/shoot1A", 16, 8, 23)

local sprShoot2 = Sprite.load("oracle_shoot2", "oracle/shoot2", 5, 8, 19)

local sprShoot3 = Sprite.load("oracle_shoot3", "oracle/shoot3", 3, 8, 19)
local sprShoot3A = Sprite.load("oracle_shoot3A", "oracle/shoot3A", 3, 8, 19)

local sprShoot4 = Sprite.load("oracle_shoot4", "oracle/shoot4", 2, 500, 250)


local sprSkills = Sprite.load("oracle_skills", "oracle/skills", 5, 0, 0)


local sprWreathFire = Sprite.load("oracle_wreathfire", "oracle/wreathfire", 1, 1, 1)

local sprWreathFireA = Sprite.load("oracle_wreathfireA", "oracle/wreathfireA", 1, 1,1 )

--speed

oracle:addCallback("init", function(player)
	player:set("adapt", 0)
end)

--local adapt = player("")

oracle:addCallback("step", function(player)
	if player:get("adapt") >= 1 then
		if player:get("pHmax") < 2.8 then
			player:set("pHmax", 2.8)
		elseif player:get("pHmax") > 2.8 then
			player:set("pHmax", 2.8)
		end
		if player:get("pVmax") < 8 then
			player:set("pVmax", 8)
		elseif player:get("pVmax") > 8 then
			player:set("pVmax", 8)
		end

	elseif player:get("adapt") < 1 then
		if player:get("pHmax") > 1.4 then
			player:set("pHmax", 1.4)
			--player:set("pHmax", player:get("pHmax") - 0.05)
		elseif player:get("pHmax") < 1.4 then
			player:set("pHmax", 1.4)
			--player:set("pHmax", player:get("pHmax") + 0.005)
		end
		if player:get("pVmax") > 3.5 then
			player:set("pVmax", 3.5)
		elseif player:get("pVmax") < 3.5 then
			player:set("pVmax", 3.5)
		end
	end
end)

--adapt buff
local adaptBuff = Buff.new()

adaptBuff.sprite = Sprite.load("oracle/adapt.png", 1, 7, 4)


adaptBuff:addCallback("start", function(player)
	player:set("adapt", 1)
	--player:applyBuff(adapt, 9 * 60)

	player:set("armor", player:get("armor") + 18)

	player:setAnimation("walk", sprites.walkA)
	player:setAnimation("jump", sprites.jumpA)
	player:setAnimation("idle", sprites.idleA)
	player:setAnimation("climb", sprites.climbA)
	--player:setAnimation("shoot1", sprites.sprShoot1A)
	--player:setAnimation("shoot3", sprites.shoot3A)
end)


adaptBuff:addCallback("end", function(player)
	player:set("adapt", 0)

	player:set("armor", player:get("armor") - 10)

	player:setAnimation("walk", sprites.walk)
	player:setAnimation("jump", sprites.jump)
	player:setAnimation("idle", sprites.idle)
	player:setAnimation("climb", sprites.climb)
	--player:setAnimation("shoot1", sprites.sprShoot1)
	--player:setAnimation("shoot3", sprites.sprShoot3)
end)


--ring buff
local fireRing = Buff.new()
fireRing.sprite = Sprite.load("oracle/ringBuff.png", 1, 7, 4)

--local fTick = {}
oracle:addCallback("init", function(player)
	player:set("fTick", 0)
end)

--local burnt = {}
oracle:addCallback("init", function(player)
	player:set("burnt", 0)
end)


fireRing:addCallback("start", function(player)
	if player:get("fTick") == 0 then
		player:set("fTick", player:get("fTick") + 1)
	end
end)

fireRing:addCallback("end", function(player)
	
	player:set("fTick", 0)
	
end)

oracle:addCallback("step", function(player)
	if player:get("fTick") > 0 then 
		if player:get("adapt") >= 1 then
		
			local bullet = player:fireExplosion(player.x + 80, player.y, 12 / 19, 12 / 4, 0.9, sprWreathFireA, nil)
			bullet:set("burnt", 1)
			bullet:set("knockback", 0)
			bullet:set("damage", player:get("damage") * 0.001)	

			local bullet = player:fireExplosion(player.x - 80, player.y, 12 / 19, 12 / 4, 0.9, sprWreathFireA, nil)
			bullet:set("burnt", 1)
			bullet:set("knockback", 0)
			bullet:set("damage", player:get("damage") * 0.001)

			local bullet = player:fireExplosion(player.x, player.y + 80, 12 / 19, 12 / 4, 0.9, sprWreathFireA, nil)
			bullet:set("burnt", 1)
			bullet:set("knockback", 0)
			bullet:set("damage", player:get("damage") * 0.001)

			local bullet = player:fireExplosion(player.x, player.y - 80, 12 / 19, 12 / 4, 0.9, sprWreathFireA, nil)
			bullet:set("burnt", 1)
			bullet:set("knockback", 0)
			bullet:set("damage", player:get("damage") * 0.001)

			local bullet = player:fireExplosion(player.x + 60, player.y - 60, 12 / 29, 12 / 4, 0.9, sprWreathFireA, nil)
			bullet:set("burnt", 1)
			bullet:set("knockback", 0)
			bullet:set("damage", player:get("damage") * 0.001)

			local bullet = player:fireExplosion(player.x + 60, player.y + 60, 12 / 19, 12 / 4, 0.9, sprWreathFireA, nil)
			bullet:set("burnt", 1)
			bullet:set("knockback", 0)
			bullet:set("damage", player:get("damage") * 0.001)

			local bullet = player:fireExplosion(player.x - 60, player.y - 60, 12 / 19, 12 / 4, 0.9, sprWreathFireA, nil)
			bullet:set("burnt", 1)
			bullet:set("knockback", 0)
			bullet:set("damage", player:get("damage") * 0.001)

			local bullet = player:fireExplosion(player.x - 60, player.y + 60, 12 / 19, 12 / 4, 0.9, sprWreathFireA, nil)
			bullet:set("burnt", 1)
			bullet:set("knockback", 0)
			bullet:set("damage", player:get("damage") * 0.001)
			
		else

			local bullet = player:fireExplosion(player.x + 80, player.y, 12 / 19, 12 / 4, 0.9, sprWreathFire, nil)
			bullet:set("burnt", 1)
			bullet:set("knockback", 0)
			bullet:set("damage", player:get("damage") * 0.001)	

			local bullet = player:fireExplosion(player.x - 80, player.y, 12 / 19, 12 / 4, 0.9, sprWreathFire, nil)
			bullet:set("burnt", 1)
			bullet:set("knockback", 0)
			bullet:set("damage", player:get("damage") * 0.001)

			local bullet = player:fireExplosion(player.x, player.y + 80, 12 / 19, 12 / 4, 0.9, sprWreathFire, nil)
			bullet:set("burnt", 1)
			bullet:set("knockback", 0)
			bullet:set("damage", player:get("damage") * 0.001)

			local bullet = player:fireExplosion(player.x, player.y - 80, 12 / 19, 12 / 4, 0.9, sprWreathFire, nil)
			bullet:set("burnt", 1)
			bullet:set("knockback", 0)
			bullet:set("damage", player:get("damage") * 0.001)

			local bullet = player:fireExplosion(player.x + 60, player.y - 60, 12 / 29, 12 / 4, 0.9, sprWreathFire, nil)
			bullet:set("burnt", 1)
			bullet:set("knockback", 0)
			bullet:set("damage", player:get("damage") * 0.001)

			local bullet = player:fireExplosion(player.x + 60, player.y + 60, 12 / 19, 12 / 4, 0.9, sprWreathFire, nil)
			bullet:set("burnt", 1)
			bullet:set("knockback", 0)
			bullet:set("damage", player:get("damage") * 0.001)

			local bullet = player:fireExplosion(player.x - 60, player.y - 60, 12 / 19, 12 / 4, 0.9, sprWreathFire, nil)
			bullet:set("burnt", 1)
			bullet:set("knockback", 0)
			bullet:set("damage", player:get("damage") * 0.001)

			local bullet = player:fireExplosion(player.x - 60, player.y + 60, 12 / 19, 12 / 4, 0.9, sprWreathFire, nil)
			bullet:set("burnt", 1)
			bullet:set("knockback", 0)
			bullet:set("damage", player:get("damage") * 0.001)
		end
		--player:set("ringPos", player:get("ringPos") + 1)
	elseif player:get("fTick") == 0 then
		--player:set("ringPos", 0)
	end
end)


local BurnBuff = Buff.new()
BurnBuff.sprite = Sprite.load("oracle/burn.png", 1, 7, 4)


registercallback("onHit", function(bullet, hit, hitx, hity)
	
	if bullet:get("burnt") then
		hit:applyBuff(BurnBuff, 5 * 60)
	end
end)

BurnBuff:addCallback("step", function(actor, player)
	 
	actor:set("hp", actor:get("hp") * 0.8)
	
end)
--end of the wreath sh*t

--helio code   (unused)
--local helio = Buff.new()
--
--oracle:addCallback("init", function(player)
--player:set("helios", 0)
--end)


--helio:addCallback("start", function(player)
--	
--	player:set("helios", 1)
--	
--end)

--helio:addCallback("end", function(player)
--	
--	player:set("helios", 0)
--	
--end)

--oracle:addCallback("step", function(player)
--	if player:get("helios") > 0 then 
--		local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection(7.5), 100 * player:get("pHmax"), 2, nil, DAMAGER_BULLET_PIERCE)
--		bullet:set("climb", i * 8)
--		bullet:set("damage", player:get("damag   (this code was a couple of hundred lines long, so i deleted it so it wouldnt clog up the file.
--												  it was just a lot of bullets, mostly identical to the shoot4 code currently in use)
--end)
--end helio

oracle:setLoadoutInfo( 
[[&y&The Oracle of the Sun&!& utilises &y&devastating&!& attacks powered by the wrath of the a faraway star. 
Unleashing terrifying power, and always adapting, it is the perfect scout, warrior, survivor, 
and executioner. It travels slowly, but never stops moving, never stops seeing, and any "prophecy' 
it delivers will tell only of &y&Death and Fear.&!&]], sprSkills)

oracle:setLoadoutSkill(1, "Hand of the Sun",
[[&y&Observe&!& the land and the foes around you, and disaprove 
for &y&240%&!& damage.]])

oracle:setLoadoutSkill(2, "study, Consider, AMEND",
[[&y&Study&!& and adapt to this broken world, then reject it and burn, 
granting yourself &y&massive power&!& while your flame burns bright.]])

oracle:setLoadoutSkill(3, "Divine Arbitration",
[[&y&Evaluate&!& your surroundings, and scorn their puny inadequence
with flames ready to enact your &y&Divine Judgement&!&]]
--[[&y&Evaluate&!& the worth of your surroundings, find it inadequate, 
and scorn the space around you with a wreath of flame, 
igniting anything that would defy your Divine Judgement.]])

oracle:setLoadoutSkill(4, "Mortem De Solis",
[[You &y&Saw,&!& you &y&Learnt,&!& you &y&Evaluated,&!& and you are not pleased. 
Infict your &!&Sun's&y& wrath, &y&Your&!& wrath, and make them wish for &y&Hell.&!&]])

oracle.loadoutColor = Color(0xFF5518)

oracle.loadoutSprite = Sprite.load("oracle_select", "oracle/select", 17, 2, 0)

oracle.titleSprite = sprites.walk

--witness code

local WormEye = Item.find("Burning Witness", "vanilla")

oracle:addCallback("levelUp", function(player)
	if player:countItem(WormEye) == 1 then
		player:set("damage", player:get("damage") * 1.2)
	
	elseif player:countItem(WormEye) == 2 then
		player:set("attack_speed", player:get("attack_speed") * 1.2)
	
	elseif player:countItem(WormEye) == 3 then
		player:set("hp_regen", player:get("hp_regen") * 1.2)

	end
end)

--endingquote variables

local redSoul = Item.find("Burnt Red Soul", "oracle")--275

local orangeSoul = Item.find("Shredded Orange Soul", "oracle")

local yellowSoul = Item.find("Shattered Yellow Soul", "oracle")


--oracle:addCallback("levelUp", function(player)
--	if player:countItem(redSoul) == 1 then
--		player:setAnimation("walk", sprites.walkA)
--	end
--end)

oracle:addCallback("levelUp", function(player)--281
	if player:countItem(redSoul) >= 1 then  --282
		if player:countItem(orangeSoul) >= 1 then
			if player:countItem(yellowSoul) >= 1 then
				oracle.endingQuote = "..and so it left, stronger, faster, smarter. Perfectly lethal, perfectly efficient, a perfect Oracle of a perfect Star."
			else
				oracle.endingQuote = "..and so it left, forever forced to see the horror its righteous anger had achieved."
			end
		else
			oracle.endingQuote = "..and so it left, forever forced to see the horror its righteous anger had achieved."
		end
	else
		oracle.endingQuote = "..and so it left, forever forced to see the horror its righteous anger had achieved."
	end
end)--295

oracle.loadoutWide = true


oracle:addCallback("init", function(player)

	player:setAnimations(sprites)
	player:survivorSetInitialStats(25, 20, 0.002)
	
	player:setSkill(1, "Hand of the Sun",
	"Observe the land and the foes around you, and disaprove for 240% damage.",
	sprSkills, 1,
	50)
	
	player:setSkill(2, "study, Analyse, SURVIVE",
	"&y&Study&!& and adapt to this broken world, then reject it and burn, granting &y&massive power&!& while your flame burns bright.",
	sprSkills, 2,
	18 * 60)

	player:setSkill(3, "Divine Arbitration",
	"&y&Evaluate&!& the worth of your surroundings, find it inadequate, and unleash your fury as a &y&wreath of flame&!&, igniting anything nearby.",
	sprSkills, 3,
	12 * 60)

	player:setSkill(4, "Mortem de Solis",
	"You &y&saw,&!& you &y&learnt,&!& you &y&assessed,&!& and you are not pleased. Infict the &y&Sun's&!& wrath, &y&Your&!& wrath, and make them wish for &y&Hell.&!&",
	sprSkills, 4,
	60 * 60)
end)


oracle:addCallback("levelUp", function(player)
	player:survivorLevelUpStats(3, 12, 0.0005, 6)
end)

oracle:addCallback("scepter", function(player)
	
	player:setskill(4,
	
		"Mortem De Solis",
		"You &y&saw,&!& you &y&learnt,&!& you &y&assessed,&!& and you are not pleased. Infict the &y&Sun's&!& wrath, &y&Your&!& wrath, and let your anger fuel the flames, always &y&brighter&!&, always &y&hotter&!&, always &y&faster&!&.",
		sprSkills, 5,
		50 * 60)
end)


oracle:addCallback("useSkill", function(player, skill)
	
	if player:get("activity") == 0 then 
		
		if skill == 1 then
			if player:get("adapt") >= 1 then
				player:survivorActivityState(1, sprShoot1A, 0.2, true, true)
			else
				player:survivorActivityState(1, sprShoot1, 0.2, true, true)
			end
		elseif skill == 2 then
			player:survivorActivityState(2, sprShoot2, 0.25, true, true)
		elseif skill == 3 then
			if player:get("adapt") >= 1 then
				player:survivorActivityState(3, sprShoot3A, 0.25, true, true)
			else
				player:survivorActivityState(3, sprShoot3, 0.25, true, true)
			end
		elseif skill == 4 then
			player:survivorActivityState(4, sprShoot4, 0.25, true, true)
		end
		
		player:activateSkillCooldown(skill)
	end
end)


oracle:addCallback("onSkill", function(player, skill, relevantFrame)

	if skill == 1 then
		if relevantFrame == 10 then
			if player:survivorFireHeavenCracker(0.9) == nil then
				for i = 0, player:get("sp") do
					local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 1, 100 * player:get("pHmax"), 2, nil, DAMAGER_BULLET_PIERCE)
					bullet:set("climb", i * 8)
					bullet:set("damage", player:get("damage") * 2.8)
				end
			end
		end

	elseif skill == 2 then
		if relevantFrame == 1 then
			player:applyBuff(adaptBuff, 9 * 60)
		end
	
	elseif skill == 3 then
		if relevantFrame == 1 then
			player:applyBuff(fireRing, 6 * 60)
		end

	elseif skill == 4 then
		if relevantFrame == 1 then
			for i = 0, player:get("sp") do
				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection(), 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)
				
				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 20, 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)

				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 40, 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)

				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 60, 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)

				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 75, 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)

				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 90, 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)

				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 110, 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)

				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 130, 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)

				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 150, 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)

				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 165, 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)

				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 180, 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)

				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 200, 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)
				
				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 220, 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)

				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 240, 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)

				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 255, 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)

				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 270, 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)

				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 290, 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)

				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 310, 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)

				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 330, 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)

				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 345, 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)

				local bullet = player:fireBullet(player.x, player.y, player:getFacingDirection() + 360, 350, 2, nil, DAMAGER_BULLET_PIERCE)
				bullet:set("climb", i * 8)
				bullet:set("damage", player:get("damage") * 100)


			end
			--player:applyBuff(helio, 1 * 60)		
		end
	end
end)




